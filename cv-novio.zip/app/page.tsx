import CVNovio from "../cv-novio"

export default function Page() {
  return <CVNovio />
}
